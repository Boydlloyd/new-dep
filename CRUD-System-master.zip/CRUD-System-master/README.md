# CRUD-System
CRUD system using Django and Ajax

**history lession**

[01 CRUD system using Django & Ajax - Intro](https://github.com/mhadiahmed/CRUD-System/tree/ef7883571020d979ffb52b2392c1936661a8cb83)

[03 CRUD system using Django & Ajax - create part 1](https://github.com/mhadiahmed/CRUD-System/tree/a6a2c8fff489c72192be5f0fe0b2ddf979a577f6)

[04 CRUD system using Django & Ajax - create part 2](https://github.com/mhadiahmed/CRUD-System/tree/11c813d1f4b9876bcb31009da8a13a25ca55bd36)



[05 CRUD system using Django & Ajax - Update  Dome tree](https://github.com/mhadiahmed/CRUD-System/tree/11c813d1f4b9876bcb31009da8a13a25ca55bd36)

[06 CRUD system using Django & Ajax - Update](https://github.com/mhadiahmed/CRUD-System/tree/d6558690784146e15705d99dd847db4527677fec)


[09 CRUD system using Django & Ajax - Delete](https://github.com/mhadiahmed/CRUD-System/tree/e6a67c5fe5397c4fed979627c42a68bd083a5957)

